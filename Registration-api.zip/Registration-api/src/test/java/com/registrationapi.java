package com;

public class registrationapi {
}
