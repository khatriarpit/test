package com.registrationapi.service;

import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Registration service
 *
 * @author  Arpit Khatri
 * @version 1.0
 * @since   2019-07-29
 */
@Service
public class RegistrationService {

    /**
     *
     * @param payload
     * @return
     */
    public Map<String,Object> registerUser(Map<String, Object> payload) {
        // Do operation
        return payload;
    }
}
