package com.registrationapi.utility;

public interface Constants {
	static final String REGISTER_USER = "/register-user";
}
