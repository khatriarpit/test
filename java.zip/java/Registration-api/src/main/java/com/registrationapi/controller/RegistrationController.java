package com.registrationapi.controller;

import com.registrationapi.exception.ResourceNotFoundException;
import com.registrationapi.service.RegistrationService;
import com.registrationapi.utility.Constants;
import com.registrationapi.utility.JsonRequestMapping;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

/**
 * Registration controller which will accept
 * request and forward to service layer for further processing
 *
 * @author Arpit Khatri
 * @version 1.0
 * @since 2019-07-29
 */
@RestController
@RequestMapping("/api/v1")
@Api(value = "Registration Api", description = "Registration service")
@CrossOrigin
public class RegistrationController {

    @Autowired
    RegistrationService registrationService;

    /**
     * This method is for register user .
     *
     * @param payload
     * @return
     * @throws ResourceNotFoundException
     */
    @ApiOperation(value = "Register user")
    @JsonRequestMapping(value = Constants.REGISTER_USER, method = RequestMethod.POST)
    public ResponseEntity<Object> registration(
            @Valid @RequestBody Map<String, Object> payload) throws ResourceNotFoundException {
        Map<String, Object> response = registrationService.registerUser(payload);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
